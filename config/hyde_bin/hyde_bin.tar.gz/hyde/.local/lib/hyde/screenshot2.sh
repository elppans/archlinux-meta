#!/bin/bash
source $HOME/.config/hyde/.local/bin/hyde-shell
XDG_PICTURES_DIR="$(xdg-user-dir PICTURES)"
export XDG_PICTURES_DIR
$LIB_DIR/hyde/screenshot.sh "$@"

