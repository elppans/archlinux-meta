#!/usr/bin/env bash

scrDir="$(dirname "$(realpath "$0")")"
"${scrDir}"/theme.select.sh "$@"
