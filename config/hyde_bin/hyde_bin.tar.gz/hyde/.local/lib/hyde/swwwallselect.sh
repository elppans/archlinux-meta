#!/usr/bin/env bash

echo "DEPRECATION NOTICE: Use this command instead 'wallpaper.sh --select --backend swww --global'"
wallpaper.sh --select --backend swww --global
